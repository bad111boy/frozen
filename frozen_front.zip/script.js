

var fixmeTop = $('.contact').offset().top;       

$(window).scroll(function() {                  

    var currentScroll = $(window).scrollTop(); 
    
    if (currentScroll >= fixmeTop) 
    {          
        $('.contact').css({                     
        position: 'fixed',
        top: '0'
        });
        
    } else {                                  
                $('.contact').css({                     
                position: 'static'
                 });
            }

});  //$(window).scroll(function() { 

       