
<?php 
include 'connect.php'; //FILL THIS UP

if(isset($_GET['delete']))
	{
		$value=$_GET['delete'];
		$mysqli->query("DELETE FROM unites WHERE value= '".$value."' ");
    }
?>



<html>
    <head>
        <!--AJAX-->
        <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
        <!--AJAX-->
        
        <!--JQUERY-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <!--JQUERY-->
        
        <!--CSS-->
        <link rel="stylesheet" href="style.css">
        <!--CSS-->
        
        
    </head>
    <body>
        <div class="container">
            <div class="cointainer_child">
                
                <form method="POST" id="ajax_send_data">
    
                    <?php
                    
                        $result=$mysqli->query("SELECT * FROM unites ORDER BY value DESC") or die($mysqli->error());
                        $rows = $result->num_rows;
                        
                        $count_array=1;
                        
                        if($rows>0):
                        
                    ?>
                    
                    <input type="text" class="to_sql" name="big" value=""><br>
                    
                    <?php 
                    
                        endif; 
                        
                        while($roww = $result ->fetch_assoc())
                        {
                            $array_unit_name[$count_array]=$roww['nume'];
                            $array_unit_value[$count_array]=$roww['value'];
                            $count_array=$count_array+1;
                        }
                        if($rows>0):
                            for ($i = 1; $i < count($array_unit_name); $i++):
                        
                                 $empty_add=($array_unit_value[$i]+$array_unit_value[$i+1])/2;
                        
                    ?>
                            <a style="color:red;" href="unites.php?delete=<?php echo $array_unit_value[$i]; ?>">
                                
                                 I want to delete this!
                                 
                            </a>
                            
                            <input type="text" class="from_sql" name="from_sql_name<?php echo $i;?>" value="<?php echo $array_unit_name[$i]; ?>">
                            
                            <input type="hidden" name="from_sql_value<?php echo $i;?>" value="<?php echo $array_unit_value[$i]; ?>">
                            
                            <br>
                            
                            <input type="text" class="to_sql" name="to_sql_name<?php echo $i;?>" value="">
                            
                            <input type="hidden" name="to_sql_value<?php echo $i;?>" value="<?php echo $empty_add; ?>">
                            
                            <br>
    
                     <?php endfor;?>
    
                        
                            <input  type="hidden" 
                                    name="count_array" 
                                    value="<?php echo count($array_unit_name); ?>">
                            
                            <a  style="color:red;" 
                                href="unites.php?delete=<?php echo $array_unit_value[count($array_unit_value)]; ?>"> 
                            
                                I want to delete this!
                            
                            </a>
                            
                            <input  type="text" 
                                    class="from_sql" 
                                    name="from_sql_name<?php echo count($array_unit_value); ?>" 
                                    value="<?php echo $array_unit_name[count($array_unit_name)]; ?>">
                            
                            <input  type="hidden" 
                                    name="from_sql_value<?php echo count($array_unit_value); ?>" 
                                    value="<?php echo $array_unit_value[count($array_unit_value)]; ?>">
                                    
                            <br>
    
                     <?php  endif;?>
    
                        <?php if($rows==0):  ?>
                        
                        <input  type="text" 
                                class="from_sql" 
                                name="first_unit" 
                                required>
                        
                        <?php endif; ?>
    
                        <?php if($rows>0): ?>
                        
                        <input  type="text" 
                                class="to_sql" 
                                name="small" 
                                value="">
                        
                        <br>
                        
                        <?php endif; ?>
    
    
    
                            <button type="submit" 
                                    id="add_now">
                                
                                Submit !
                                
                            </button>
    
                </form>
                
                <button  id="i_dont_want_to_add">
                    
                    I don't want to add!
                    
                </button>
                
                <button  id="i_want_to_add">
                    
                     I want to add!
                    
                </button>
            </div>
        </div>
    
<script src="script.js"></script>    
    
    </body>
</html>

