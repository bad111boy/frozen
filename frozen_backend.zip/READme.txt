1. OPEN 'connect.php' file and FILL the fields UP.
2. SET UP THE DATABASE the same as the photo attached shows. (SQL.png) 