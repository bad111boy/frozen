<?php 
$host = "";       // FILL THIS UP !
$dbUsername = ""; // FILL THIS UP !
$dbPassword = ""; // FILL THIS UP !
$dbname = "";     // FILL THIS UP !


$mysqli = new mysqli($host, $dbUsername, $dbPassword, $dbname);


?>