
$("#i_want_to_add").click(function(){
$("#i_want_to_add").css({"opacity": "0","transition":"1s"});
$("#i_dont_want_to_add").css({"opacity": "1","transition":"1s"});
$(".to_sql").css({"opacity": "1","transition":"1s"});
$("#add_now").css({"opacity": "1","transition":"1s"});

}); //$("#i_want_to_add").click(function(){

$("#i_dont_want_to_add").click(function(){
$("#i_dont_want_to_add").css({"opacity": "0","transition":"1s"});
$("#i_want_to_add").css({"opacity": "1","transition":"1s"});
$(".to_sql").css({"opacity": "0","transition":"1s"});
$("#add_now").css({"opacity": "0","transition":"1s"});

}); //$("#i_dont_want_to_add").click(function(){
    

      
$("#ajax_send_data").submit(function(e) {   
    e.preventDefault(); // avoid to execute the actual submit of the form.

    var form = $(this);
    var url = form.attr('action');

 $.ajax({
        type: "POST",
        url: "add_unites.php",
        data: form.serialize(),
        dataType: 'json'
    }).done(function(data) {
     
    if(data==1)
    { 
     alert("Unit added!");
     location.replace('unites.php');
    }else  if(data==2)
            { 
                alert("Unit couldn't be added!");
            }
             
    }); // }).done(function(data) {

   


}); // $("#ajax_send_data").submit(function(e) { 

