<?php 
include 'connect.php'; //FILL THIS UP

$result=$mysqli->query("SELECT * FROM unites ");
$rows = $result->num_rows;

if($rows==0)
{
    $unit_name_first=$_POST['first_unit'];
    
    $sqL= "INSERT INTO unites (nume,value)  values 
    ('".$unit_name_first."',1000000000000)";
    
    if($mysqli->query($sqL))
        { 
         echo json_encode(1);
        }
          
}
else if($rows>0)
{
    $count_array=$_POST['count_array'];
    $big=$_POST['big'];
    $small=$_POST['small'];
    
    if(!empty($big))
    {
        $B_value=$mysqli->query("SELECT * FROM unites ORDER BY value DESC ") or die($mysqli->error());
        $get_value=$B_value->fetch_array();
        
        $val_big=$get_value['value']+1;
        
        $sqL= "INSERT INTO unites (nume,value)  values 
                ('".$big."','".$val_big."')";

            if($mysqli->query($sqL)) {}
    }
      if(!empty($small))
    {
        $S_value=$mysqli->query("SELECT * FROM unites ORDER BY value ASC ") or die($mysqli->error());
        $get_value=$S_value->fetch_array();
        
        $val_small=$get_value['value']-1;
        
        $sqL= "INSERT INTO unites (nume,value)  values 
                ('".$small."','".$val_small."')";

            if($mysqli->query($sqL)) {}
     }
     
     
    $value="to_sql_value";
    $name="to_sql_name";
    
    for($i=1;$i<=$count_array;$i++)
    {
        $add_value1=$value.$i;
        $add_name1=$name.$i;
        $to_sql_value1=$_POST[$add_value1];
        $to_sql_name1=$_POST[$add_name1];
        
        if(!empty($to_sql_name1))
        {
            $sqL= "INSERT INTO unites (nume,value)  values 
                ('".$to_sql_name1."','".$to_sql_value1."')";

            if($mysqli->query($sqL)) {}
        }
    }
    
    $value_from_sql="from_sql_value";
    $name_from_sql="from_sql_name";
    for($i=1;$i<=$count_array;$i++)
    {
        
        $add_name=$name_from_sql.$i;
        $add_value=$value_from_sql.$i;
        $to_sql_name=$_POST[$add_name];
        $to_sql_value=$_POST[$add_value];
        if(!empty($to_sql_name))
        {
            $mysqli->query("UPDATE unites SET nume='".$to_sql_name."' WHERE value='".$to_sql_value."' ");
        }
    }
echo json_encode(1);
}



?>